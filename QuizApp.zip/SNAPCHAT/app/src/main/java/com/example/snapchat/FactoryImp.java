package com.example.snapchat;

public class FactoryImp {
    boolean res = false;
}
