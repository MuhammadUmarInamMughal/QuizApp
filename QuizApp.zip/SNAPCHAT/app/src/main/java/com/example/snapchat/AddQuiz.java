package com.example.snapchat;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class AddQuiz extends AppCompatActivity implements View.OnClickListener {

    TextView tv;
    Button b1,b2,b3,b4,submit;
    int score=0;
    int totalQuestion = QuizLoader.question.length;
    int currentQuestionIndex=0;
    String selectedAnswer="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_quiz);

        tv=findViewById(R.id.txtview);
        b1=findViewById(R.id.btn1);
        b2=findViewById(R.id.btn2);
        b3=findViewById(R.id.btn3);
        b4=findViewById(R.id.btn4);
        submit=findViewById(R.id.btn5);

        tv.setOnClickListener(this);
        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);
        submit.setOnClickListener(this);

        loadNewQuestion();


    }

    @Override
    public void onClick(View view) {


        Button clickBtn =(Button)view;
        if(clickBtn.getId()==R.id.btn5){
            if(selectedAnswer.equals(QuizLoader.correctAnswers[currentQuestionIndex])){
                score++;
            }
            currentQuestionIndex++;
            loadNewQuestion();

        }
        else{
            selectedAnswer=clickBtn.getText().toString();

        }

    }
    void loadNewQuestion(){

        if(currentQuestionIndex==totalQuestion){

            finishQuiz();
            return;
        }
        tv.setText(QuizLoader.question[currentQuestionIndex]);
        b1.setText(QuizLoader.choices[currentQuestionIndex][0]);
        b2.setText(QuizLoader.choices[currentQuestionIndex][1]);
        b3.setText(QuizLoader.choices[currentQuestionIndex][2]);
        b4.setText(QuizLoader.choices[currentQuestionIndex][3]);
    }

    private void finishQuiz() {
        String passStatus="";
        if(score>totalQuestion*0.60){
            passStatus="passed";
        }
        else{
            passStatus="failed";
        }
        new AlertDialog.Builder(this)
                .setTitle(passStatus)
                .setMessage("Score :"+score)
                .setPositiveButton("Go to main page",(dialogInterface, i) -> toMainPage())
                .setCancelable(false)
                .show();
    }

    private void toMainPage() {
        Intent intent = new Intent(AddQuiz.this,StudentScreen.class);
        startActivity(intent);

    }
}