package com.example.snapchat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SignupActivity extends AppCompatActivity {

    EditText ed1, ed2;
    Button btn;
    dbHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        ed1=findViewById(R.id.username);
        ed2=findViewById(R.id.pass);
        btn=findViewById(R.id.Register);
        db=new dbHelper(this);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name,pass;
                name=ed1.getText().toString();
                pass=ed2.getText().toString();
                if(checker(name,pass)==false){
                    Toast.makeText(SignupActivity.this, "Your email should be in a proper format and password should not be empty", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(SignupActivity.this, "Yayyy! You have been registered to the database", Toast.LENGTH_SHORT).show();
                    db.insertData(name,pass);
                }
            }
        });
    }

    private boolean checker(String name,String pass) {
        if (name.contains(".com")&&name.contains("@")&&pass.length()>8){
            return true;
        }
        else{
            return false;
        }


    }
}