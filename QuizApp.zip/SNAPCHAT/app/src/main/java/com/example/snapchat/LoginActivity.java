package com.example.snapchat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    Button btn;
    EditText et1,et2;
    dbHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btn=findViewById(R.id.login);
        et1=findViewById(R.id.username);
        et2=findViewById(R.id.pass);
        DB=new dbHelper(this);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user=et1.getText().toString();
                String pass=et2.getText().toString();
                if(TextUtils.isEmpty(user)||TextUtils.isEmpty(pass)){
                    Toast.makeText(LoginActivity.this, "Please Enter all Fields", Toast.LENGTH_SHORT).show();
                }
                else if(TextUtils.equals(user,"admin")&&TextUtils.equals(pass,"admin")){
                    Intent intent = new Intent(LoginActivity.this,AdminScreen.class);
                    startActivity(intent);
                }
                else{
                    Boolean checkUserPass=DB.checkUsernamePassword(user,pass);
                    if(checkUserPass==true){
                        Intent in = new Intent(LoginActivity.this,StudentScreen.class);
                        startActivity(in);
                    }
                    else{
                        Toast.makeText(LoginActivity.this, "Incorrect Username or password", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });
    }
}