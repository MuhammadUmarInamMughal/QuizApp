package com.example.snapchat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class AdminScreen extends AppCompatActivity {


    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_screen);

        btn=findViewById(R.id.announce);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FactoryClass f=new FactoryClass();
                f.setRes(true);
                Toast.makeText(AdminScreen.this, "Result will be shown to students", Toast.LENGTH_SHORT).show();
            }
        });
    }
}