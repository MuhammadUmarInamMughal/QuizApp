package com.example.snapchat;

public class QuizLoader {
    
    public static String question[]={"The diameter of a circle is 56 inches. What is its radius?",
            "The radius of a circular carpet is 8 feet. What is its diameter?",
            "The diameter of a circle is 124 centimeters. What is its radius?",



    };
    public static String[][] choices={{"14 inches","28 inches","56 inches","112 inches"},
            {"4ft","10ft","16ft","24ft"},
            {"62","60","56","52"}};
    public static String correctAnswers[]={"28 inches","16ft","62"};

}
