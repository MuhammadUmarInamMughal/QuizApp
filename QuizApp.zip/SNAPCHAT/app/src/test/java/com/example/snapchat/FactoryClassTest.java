package com.example.snapchat;

import junit.framework.TestCase;

import org.junit.Test;

public class FactoryClassTest extends TestCase {

    @Test
    void Method1(){
        FactoryClass f = new FactoryClass();
        assertEquals(true,true);f.getRes();

    }


}