package com.example.snapchat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class StudentScreen extends AppCompatActivity{

    Button b1,b2,b3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_screen);

        b1=findViewById(R.id.result);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FactoryClass f=new FactoryClass();
                boolean r=f.getRes();
                if(r==false){
                    Toast.makeText(StudentScreen.this, "result havn't been announced", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(StudentScreen.this, "Result have been announced", Toast.LENGTH_SHORT).show();
                }
            }
        });
        b2=findViewById(R.id.quiz);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(StudentScreen.this,AddQuiz.class);
                startActivity(intent);
            }
        });
        b3=findViewById(R.id.mainpage);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(StudentScreen.this,MainActivity.class);
            }
        });


    }


}