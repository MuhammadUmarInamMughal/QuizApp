package com.example.snapchat;

public class FactoryClass {


    FactoryImp f=new FactoryImp();

    public void setRes(boolean res){
        f.res=res;
    }
    public boolean getRes(){
        return f.res;
    }
}
